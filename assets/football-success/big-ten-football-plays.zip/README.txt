Big Ten football play-by-play, 2023–2026 through 2026-11-21.
One row per rated snap per current Big Ten team perspective. Games involving two covered teams appear in both perspectives. For distinct snaps, use game_id and play_id together.
team_success is an offensive success or defensive stop for the team column. Thresholds are 50%, 70%, or 100% of yards to go on first, second, or third/fourth down.
Source: SportsDataverse ESPN parquet files, with CollegeFootballData for five games missing from ESPN. Venue is the schedule designation. Blank clocks include repeated times suppressed from the feed.
big_ten_league_game marks regular-season games between Big Ten members that season. regular_season_game_number is the team's chronological regular-season game number.
