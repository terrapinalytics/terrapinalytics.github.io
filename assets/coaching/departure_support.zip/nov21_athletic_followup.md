# November 21 coaching carousel follow-up

Source: The Athletic coaching carousel excerpt supplied by the reader. This review reflects the reporting window in that excerpt. Prior public links are retained in the dashboard and CSV.

## USC · Lincoln Riley

Forecast: 25% by December 7 and 32% by February 1.

The Athletic reports that a loss to unbeaten UCLA could increase pressure on Riley. A buyout well above $50M and the risk of losing a strong freshman class weigh against a move.

The Athletic describes the potential dismissal cost as well above $50M.

## TCU · Sonny Dykes

Forecast: 20% by December 7 and 30% by February 1.

The Athletic reports that Dykes signed an extension in April and that the buyout falls significantly after next season. TCU was 5–5 with five losses by 25 combined points. The extension and close losses give TCU reasons to wait, with Utah and Texas Tech still ahead.

The Athletic reports a significant step-down after the 2027 season. The current dollar figure remains a separate reported estimate.

## Michigan · Kyle Whittingham

Forecast: 65% by December 7 and 75% by February 1.

The Athletic reports that Michigan accelerated the hiring of Trev Alberts in part to start the Whittingham decision. Alberts takes over Dec. 1. Michigan was 5–5 entering UCLA and Ohio State, and a decision could follow quickly after the regular season.

The Athletic puts Whittingham’s buyout at roughly $25M, consistent with the displayed estimate. The $10M already committed to former offensive coordinator Jason Beck and other potential staff costs are separate.

## Clemson · Dabo Swinney

Forecast: 10% by December 7 and 18% by February 1.

The Athletic reports Clemson prefers to retain Swinney and wants him to adapt to changes in roster management and the front office. The 20–10 win at Duke lowers the immediate risk.

The Athletic reports that the $57M dismissal buyout has no offset for compensation from a subsequent job.

## Wisconsin · Luke Fickell

Forecast: 45% by December 7 and 55% by February 1.

The Athletic reports renewed uncertainty after Wisconsin followed its USC win with losses to Iowa and Maryland. A strong finish against Purdue and Minnesota could help Fickell keep the job.

The Athletic corroborates a buyout a little above $21M, subject to offset from another job.

## Cincinnati · Scott Satterfield

Forecast: 55% by December 7 and 65% by February 1.

The Athletic reports that Satterfield’s status may depend on Colorado and BYU after Cincinnati lost five of six. It also notes year-over-year improvement in the prior two seasons and a comparatively low roster budget.

The Athletic reports approximately $5.5M, half due within 90 days, with an offset. USA Today described equal monthly installments over twice the remaining term and estimated $5.86M for a mid-November dismissal. The payment schedule remains unresolved.

## California · Tosh Lupoi

Forecast: 12% by December 7 and 18% by February 1.

The Athletic flagged friction surrounding the first-year staff and football leadership. Cal entered the Stanford game 3–7. The rivalry result bears watching, with a $14.8M buyout weighing against a move after one season.

The Athletic corroborates the $14.8M estimate and reports that it is subject to offset.
