# Dashboard buyout audit — November 10, 2026

25 existing dashboard rows retained. No odds, February 1 values, rankings or tiers changed. All 79 ranked programs remain in master. Five recent research leads remain outside the saved 25-row dashboard; their provisional odds were not silently adopted.

## Major gap research

- Alabama: replace obsolete 60.84M Dec2025 reference with reported >67.5M November2026 obligation. On3 Wilson Alexander Apr22 confirms 90% remainder/no mitigation; Matt Stahl/AL.com syndicated Yahoo reports >67.5M. Alabama Gazette 80% claim conflicts with the better-supported 90% and is rejected pending primary contract. The 10M figure is what DeBoer owes to leave, not Alabama firing him. https://www.on3.com/news/alabama-and-football-coach-kalen-deboer-agree-to-contract-extension/

- Boston College: FOS Nov10 says 3.8M; David Wasson/SDS Feb3 says 12.5M with no contract calculation. Preserve both as unresolved reports, not a range or verified point estimate. https://www.saturdaydownsouth.com/news/college-football/the-5-college-football-coaches-on-the-hottest-seats-entering-the-2026-season/

- Washington: 33.686666M is explicitly Dec1,2025, despite trackers labeling it current. A separate aggregator says 27.2M, but its underlying contract was not obtained. Do not amortize or promote that number. FootballScoop detail retrieval returned 403. https://sports.yahoo.com/article/washington-football-coach-jedd-fisch-101847958.html

- Syracuse: Sporting News Nov2025 estimate assumes salary and guarantee structure; 12–15M is hypothetical, not a current sourced obligation. Leave unknown.

- TCU: Dave Campbell industry-source >25M and possible reduction during extension remain unverified against private contract. No credible newer definitive amount recovered.

- Texas A&M: KBTX Feb17 contract reporting corroborates the formula and automatic-extension trigger. Aggies Wire Oct27 estimates 54.62M vs67.08M and explicitly says extension activation unconfirmed. Keep two conditional scenarios; do not assert upper scenario as fact. https://www.kbtx.com/2026/02/17/new-contract-texas-ams-mike-elko-modernized-current-college-athletics-landscap/

- NC State: 9.75M excludes roughly 0.6055M remaining2026. Use ~10.3M dismissal-date total with offset caveat; do not treat the two published totals as wholly contradictory.

- Additional five-school leads: Oklahoma ~51.67M year-end and Georgia Tech18.45M already reported; Cal ~14.5M is source-specific and exact date/remaining-period treatment needs contract reconciliation. Virginia AFP obtained only2022 contract after seeking amended2026 terms; a22.6M remaining-pay discussion is explicitly conditional on old termination provisions surviving. Do not call it a verified buyout. Pitt automated25.56/28.7M estimates have no obtained contract support and are excluded. https://augustafreepress.com/news/uva-football-still-trying-to-figure-out-the-tony-elliott-buyout-terms/

## Definitions and source registry

USD nominal; no inflation adjustment. Values are source observations, not synchronized daily valuations. Nulls indicate unavailable/uncertain current points; never zero. Lower bounds are labeled; private estimates and conditional scenarios are separate. General source review does not replace obtaining signed contracts. No public-records requests were submitted. Retrieval date Nov10,2026 local client date. Source-native financial precision is retained only where supported; no new prorated amount calculated.

|School|Display|Classification|Applicable date/period|Notes|Source|
|---|---|---|---|---|---|
|Florida State|50.3M|reported|2026-11-01|Offset/mitigation applies; dismissal-date obligation.|https://frontofficesports.com/article/cfb-firings-tracker-nc-state-maryland-owe-nearly-20m-to-coaches/|
|Maryland|9.75M|reported|2026 dismissal|About half due within 60 days.|https://frontofficesports.com/article/maryland-mike-locksley-firing-owed-10m/|
|NC State|~10.3M|reported|2026-10-24|Includes roughly 0.6055M remaining 2026 plus 9.75M later years; coaching offsets.|https://packinsider.com/2026/10/24/dave-doeren-buyout-nc-state-contract-10-million/|
|Baylor|~12M|estimate|2026 dismissal|Private contract; reported estimate.|https://frontofficesports.com/article/cfb-firings-tracker-nc-state-maryland-owe-nearly-20m-to-coaches/|
|TCU|>25M? [U]|uncertain|2026-10-01 report|Industry sources say north of 25M; extension may have lowered it; no public contract. Not a verified lower bound.|https://www.davecampbells.com/articles/2026/10/01/hot-seat-or-hot-water-sonny-dykes-tcu-at-a-crossroads|
|Boston College|3.8 / 12.5M [U]|conflict|2026 reports|FOS updated Nov10 says 3.8M; David Wasson/SDS Feb3 says 12.5M. Neither supplies contract calculation. Do not interpret as statistical range.|https://frontofficesports.com/article/cfb-firings-tracker-nc-state-maryland-owe-nearly-20m-to-coaches/|
|Michigan|24.75M|reported|2026|Reported dismissal obligation.|https://frontofficesports.com/article/cfb-firings-tracker-nc-state-maryland-owe-nearly-20m-to-coaches/|
|USC|~57M [U]|estimate|2026 reporting|USA TODAY person familiar with contract; no public agreement. Voluntary departure fee reportedly waived after AD change; distinct from dismissal.|https://sports.yahoo.com/articles/usc-football-lincoln-riley-headed-091114265.html|
|Colorado|25.5M|reported|2026|Source-specific estimate; not daily prorated here.|https://frontofficesports.com/article/cfb-firings-tracker-nc-state-maryland-owe-nearly-20m-to-coaches/|
|Nebraska|63M|reported|end of 2026|USA TODAY updated-contract report; old 49.6M database value superseded.|https://staging-aws.sports.yahoo.com/articles/nebraska-5-0-four-losses-125030888.html|
|Clemson|57M|reported|2026|Flat 2026 dismissal amount.|https://sports.yahoo.com/articles/dabo-swinneys-buyout-clemson-football-174404735.html|
|Kansas|~17.9M|reported|2026-12-01|Monthly over 12 months; mitigation and offsets.|https://sports.yahoo.com/articles/kansas-football-coach-lance-leipold-210122753.html|
|Washington|33.69M [OLD]|outdated|2025-12-01|Historical benchmark only. Current 27.2M aggregator claim not promoted without underlying contract.|https://sports.yahoo.com/article/washington-football-coach-jedd-fisch-101847958.html|
|North Carolina|~10M|reported|after 2026 season|Remaining guaranteed 2027 pay; 20.83M older number not current.|https://sports.yahoo.com/articles/bill-belichick-hot-seat-unc-084536197.html|
|Arkansas|~19M|estimate|end of 2026|70% remaining compensation; mitigation and offsets.|https://sports.yahoo.com/articles/former-memphis-player-isnt-alone-013000472.html|
|Purdue|~20.25M|reported|end of 2026|75% remaining base salary, paid monthly, no offset per reporting.|https://www.foxsports.com/stories/college-sports/purdue-barry-odom-buyout-contract-2026|
|Wisconsin|~21.3M|reported|2026-12-01|80% initial-contract compensation subject to floor; mitigation/offsets.|https://sports.yahoo.com/articles/wisconsin-football-coach-luke-fickells-184605020.html|
|Mississippi State|~7.65M|reported|2026-12-01|Clarion Ledger reports 75% remaining salary; 7.66M in earlier coverage is rounding difference.|https://www.aol.com/articles/jeff-lebbys-buyout-mississippi-state-005430000.html|
|South Carolina|~22.5M|estimate|2026 reporting|Head coach only; transition-cost estimates are separate.|https://www.cbssports.com/college-football/news/shane-beamer-south-carolina-future-hot-seat-buyout/|
|Rutgers|~18.5M|reported|after 2026 season|Paid biweekly through term; new-job offsets.|https://www.on3.com/rivals/news/greg-schiano-buyout-details-of-rutgers-scarlet-knights-head-coach-contract/|
|Texas A&M|54.62 / 67.08M [U]|conditional|after 2026 season|Aggies Wire estimate: 54.62M base-term scenario; 67.08M if automatic extension activated. Activation unconfirmed by reporter. Not a confidence interval.|https://www.aol.com/articles/could-texas-m-face-another-193136000.html|
|Texas|50.15M|reported|after 2026 season|85% remaining balance per reporting.|https://www.cbssports.com/college-football/news/steve-sarkisian-buyout-contract-texas-coach/|
|Alabama|>67.5M|reported_lower_bound|November 2026|Post-April extension: 90% remaining compensation; no mitigation or offset. 67.5M is lower-bound report, not exact payroll-date figure.|https://sports.yahoo.com/articles/much-alabama-pay-fire-kalen-221625838.html|
|Penn State|~61.68M|estimate|after first season|Published estimate; official term sheet guarantees remainder subject to mitigation.|https://nittanycentral.com/penn-state-football-matt-campbell-buyout-contract-future-college-football-news/|
|Syracuse|Undisclosed|unavailable|2026 review|Sporting News 12–15M discussion is a 2025 hypothetical using assumed salary/guarantee. Excluded as current verified amount.|https://www.sportingnews.com/us/ncaa-football/news/fran-brown-buyout-contract-details-syracuse-orange-head-coach/3dcbfa3f6bec8855ca9f0c3c|

## Best-estimate display and VIP re-review

The dashboard now shows one working estimate per coach, with source flags removed at user request. Original observations remain nested in each buyout record. Point selection does not resolve documentary conflicts. Syracuse remains unavailable rather than fabricated.
TCU: Jeremy Clark, Nov7 and subsequent replies in the same thread, rejects a loss-triggered or season-end buyout reduction and describes installment payments. He labels anticipated Nov13 board-meeting/decision timing as opinion and says he has no new information. No exact amount disclosed. https://247sports.com/college/tcu/board/101445/contents/is-there-any-smoke-at-all--292319793/?page=1
BC: AJ Black Oct15 8:49AM says contract has not been disclosed. He also rejects a fan assertion of unequivocal administration support. Neither statement verifies a dollar amount. Fan calculations in search results excluded as contract evidence. https://247sports.com/college/boston-college/board/59454/contents/kenyatta-watson-gone-291271711/?page=2#M291289096
BC selection 3.8M favors current FOS reporting over older 12.5M claim; unresolved, low confidence. TCU 25M is a rounded working estimate. Washington 27.2M is secondary/unverified current estimate, not extrapolated from 2025. A&M67.08M selects likely extension scenario, activation still unconfirmed. No new odds adjustment supported by this limited board review.
VIP scope this refresh: TCU staff-only thread and BC native buyout search with linked reporter reply; not a fresh crawl of all25 sites.