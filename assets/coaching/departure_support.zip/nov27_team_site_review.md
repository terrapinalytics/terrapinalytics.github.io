# November 27 team-site follow-up

USC
December 7 moved from 15% to 20%. February 1 moved from 25% to 30%.
HornedFrogBlitz’s Jeremy Clark reported that Lincoln Riley was a TCU candidate as of November 23. His post left an interview unresolved and identified cost as a concern. USC’s Peristyle thread relays the same reporting. This gives the voluntary-exit scenario more weight, although newer national coverage is skeptical of a deal.
https://247sports.com/college/tcu/board/101445/contents/tcu-head-coach-hot-board-40-291956466/?page=36#M293224803
https://247sports.com/college/usc/board/102339/contents/pete-thamel-on-lincoln-riley-and-tcu-via-tcu-247-293230548/?page=1

Colorado
December 7 moved from 40% to 60%. February 1 moved from 50% to 70%.
BuffInsider’s Jack Carlough expects the UCF finale to be Sanders’ last game. He also highlighted Phillip Dukes’ discussion of potential successors, including Jason Eck. Carlough described his read of the situation and left confirmation to CU leadership. The roughly $25.5 million dismissal cost and uncertainty about any negotiated exit still matter.
https://247sports.com/college/colorado/board/104133/contents/interesting-intel-on-eck-and-maryland-job-293376864/?page=1
https://247sports.com/college/colorado/board/104133/contents/new-buzz-on-coach-primes-future-293321928/?page=1

Michigan
December 7 moved from 60% to 45%. February 1 moved from 70% to 55%.
Sam Webb reports that Warde Manuel agreed to stay through the AD transition. Based on subsequent conversations, Webb believes the longer search improves Whittingham’s chances of a second year. A quick change would put the decision on incoming president C. Cybele Raver. That local reporting tempers national expectations of a departure ahead of Ohio State.
https://247sports.com/college/michigan/longformarticle/webblog-new-search-revelations-political-fallout-and-kyle-whittinghams-job-security-293329417/

Wisconsin
December 7 moved from 20% to 20%. February 1 moved from 30% to 30%.
Wisconsin led Minnesota 28–5 in the fourth quarter. The latest Hot Board discussion included a member claiming Fickell would return, without a linked announcement or staff confirmation. The in-game assessment stands pending sourced news.
https://247sports.com/college/wisconsin/board/23/contents/hot-board-20--289889901/?page=134

Mississippi State
December 7 moved from 20% to 20%. February 1 moved from 28% to 28%.
After the 41–17 Egg Bowl loss, Lebby said he had not discussed his future with administrators. True Maroon members disagreed about retention. The coaching-status thread reviewed had no staff replies or confirmed decision.
https://247sports.com/college/mississippi-state/board/59413/contents/status-of-the-ball-coach-293398409/?page=1

Cincinnati
December 7 moved from 35% to 35%. February 1 moved from 45% to 45%.
Bearcat Journal’s Chad Brendel criticized Cincinnati’s results against programs with comparable resources. His comments assess Satterfield’s performance. The reviewed discussion provides no new reporting of an administrative decision. Bowl eligibility and the win over Texas Tech still weigh in his favor.
https://247sports.com/college/cincinnati/board/39/contents/fire-satt-287515563/?page=57

California
December 7 moved from 38% to 38%. February 1 moved from 48% to 48%.
Cal entered the Pitt game 3–8 after five straight losses. Ron Rivera’s public criticism and the cost of another change remain the main considerations. The recent Oski’s Lounge listings reviewed concentrated on recruiting and supplied no new staff report on Lupoi’s job.
https://247sports.com/college/california/board/oskis-premiumlounge-102723/
