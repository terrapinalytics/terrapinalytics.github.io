# November 23 coaching carousel review

Editorial estimates as of November 23, 2026. Public board chatter is fan sentiment. Public reporting, statements and results drive the revisions.

November 8 is the latest saved forecast on or before the November 9 reference date. Changes carry that forecast forward without interpolation.

## Maryland · Mike Locksley
December 7: 100% → 100%. February 1: 100% → 100%.

The search remains open in the sources reviewed. Testudo Times reported that Brian Kelly interviewed. Jason Eck and Charles Huff have appeared in the discussion, but candidate chatter alone does not establish a frontrunner or a hire.

- https://www.testudotimes.com/maryland-terps-news/95723/mm-11-19-brian-kelly-interviewed-for-maryland-football-coaching-job
- https://www.cbssports.com/college-football/news/maryland-football-coaching-search-2026-candidates-hot-board-news/
- https://www.reddit.com/r/terps/comments/1xvbbuk/smoke_billowing_in_terp_coach_search/

## NC State · Dave Doeren
December 7: 100% → 100%. February 1: 100% → 100%.

Dave Doeren’s departure remains a confirmed event. NC State filled the opening on November 13 with Philip Rivers, who signed a five-year agreement.

- https://gopack.com/news/2026/11/13/rivers-named-head-coach-for-nc-state-football

## Baylor · Dave Aranda
December 7: 100% → 100%. February 1: 100% → 100%.

Dave Aranda’s departure remains confirmed. CBS lists Jeff Traylor, GJ Kinne and Lincoln Riley as candidates to consider. The sources reviewed did not establish a hire.

- https://baylorbears.com/news/2026/10/25/baylor-announces-change-in-football-leadership
- https://www.cbssports.com/college-football/news/college-football-coaching-carousel-tracker-grades-2026/

## USC · Lincoln Riley
December 7: 25% → 30%. February 1: 32% → 40%.

The TCU opening adds a potential voluntary exit. CBS listed Lincoln Riley as a possible candidate for TCU and Baylor. Candidate lists show a plausible path, while the dismissal cost and the remaining UCLA game still matter. No offer or agreement was identified in the sources reviewed.

- https://www.cbssports.com/college-football/news/tcu-candidates-sonny-dykes-fired-lincoln-riley-manny-diaz-gj-kinne-mike-norvell/
- https://www.cbssports.com/college-football/news/college-football-coaching-carousel-tracker-grades-2026/
- https://usctrojans.com/sports/football/schedule/2026

## Florida State · Mike Norvell
December 7: 100% → 100%. February 1: 100% → 100%.

Mike Norvell’s departure remains confirmed. Reuters reported on November 22 that the search was looking at Georgia defensive coordinator Glenn Schumann. The sources reviewed did not establish a hire.

- https://www.reuters.com/sports/report-fsu-coaching-search-eyes-georgia-dc-glenn-schumann--flm-2026-11-22/

## Rutgers · Greg Schiano
December 7: 2% → 2%. February 1: 40% → 8%.

Athletic director Keli Zinn said Greg Schiano will return in 2027. December stays at 2% and the February estimate is reduced to 8% to reflect the same commitment, allowing for an unexpected reversal or voluntary departure.

- https://www.reuters.com/sports/rutgers-retaining-greg-schiano-despite-2-7-season--flm-2026-11-10/

## TCU · Sonny Dykes
December 7: 20% → 100%. February 1: 30% → 100%.

TCU fired Sonny Dykes on November 22 and named Andy Avalos interim. The loss to Utah dropped TCU to 5–6. Reuters, citing ESPN, reports a buyout above $20 million, with the precise figure unpublished.

- https://gofrogs.com/news/2026/11/22/tcu-football-announces-change-in-leadership
- https://www.reuters.com/sports/report-tcu-fires-sonny-dykes-after-five-seasons--flm-2026-11-22/
- https://www.reddit.com/r/CFB/comments/1y2w15r/nakos_breaking_tcu_has_fired_head_coach_sonny/

## Boston College · Bill O’Brien
December 7: 45% → 35%. February 1: 50% → 45%.

Boston College beat Syracuse 27–15 and improved to 5–6. The win gives Bill O’Brien a path to bowl eligibility against Miami. Postgame discussion leaned toward giving him more time, with no verified decision in the sources reviewed.

- https://bceagles.com/news/2026/11/21/football-eagles-defeat-orange-on-senior-day
- https://www.reddit.com/r/CFB/comments/1y26z88/postgame_thread_boston_college_defeats_syracuse/

## Michigan · Kyle Whittingham
December 7: 65% → 50%. February 1: 75% → 65%.

Michigan beat No. 4 UCLA 18–16 in three overtimes and reached bowl eligibility. That strengthens Kyle Whittingham’s case. Ohio State and incoming athletic director Trev Alberts’s review still leave a material chance of a change.

- https://www.cbsnews.com/detroit/news/michigan-secures-win-over-ucla-in-3-overtimes/
- https://www.on3.com/teams/michigan-wolverines/news/newsstand-kyle-whittingham-weighs-in-on-michigan-ad-situation/
- https://mgoblog.com/mgoboard/whittingham-calls-ucla-game-signature-win

## Wisconsin · Luke Fickell
December 7: 45% → 40%. February 1: 55% → 50%.

Wisconsin beat Purdue 42–10, easing immediate pressure on Luke Fickell. Minnesota and the cost of a change remain relevant. Postgame reactions about retention reflect fan opinion.

- https://uwbadgers.com/game-center/17151
- https://www.buckys5thquarter.com/wisconsin-badgers-football/91703/wisconsin-badgers-football-news-details-luke-fickell-contract-buyout-revealed-if-fired
- https://www.reddit.com/r/CFB/comments/1y26md9/postgame_thread_wisconsin_defeats_purdue_4210/

## Cincinnati · Scott Satterfield
December 7: 55% → 45%. February 1: 65% → 55%.

Cincinnati beat Colorado 35–28 and clinched bowl eligibility after losing five of six. The win lowers immediate pressure on Scott Satterfield. BYU remains the final regular-season test.

- https://cubuffs.com/news/2026/11/21/football-colorado-falls-to-cincinnati
- https://www.on3.com/news/coaching-carousel-intel-pressure-building-at-wisconsin-cincinnati-more/
- https://www.reddit.com/r/CFB/comments/1y26fvj/postgame_thread_cincinnati_defeats_colorado_3528/

## California · Tosh Lupoi
December 7: 12% → 18%. February 1: 18% → 25%.

Cal’s 44–28 home loss to Stanford raises the risk after a difficult first year for Tosh Lupoi. The reported $14.8 million buyout and the existing Wilcox obligation still favor retention.

- https://calbears.com/news/2026/11/22/football-cal-falls-in-129th-big-game
- https://www.sfchronicle.com/sports/college/article/cal-big-hopes-big-donations-bears-stagger-big-22536578.php
- https://www.reddit.com/r/calfootball/comments/1y282zf/game_thread_california_golden_bears_vs_stanford/

## Public message boards

- [KillerFrogs](<https://forum.killerfrogs.com/index.php>), TCU’s public firing discussion. The announcement and buyout references above carry the factual claims.
- MGoBlog and the Wisconsin, Boston College and Cincinnati postgame threads are linked under each school. The discussion is directional and gives no independent confirmation of an administrative decision.
- The public r/terps search thread predates this snapshot. Its Eck and Huff discussion is older than the interview reporting. Subscription-only posts were outside the review.
