# Coaching dashboard review — November 20, 2026

Target: publicly open job or publicly acknowledged search by December 7. These are analyst judgments, not reporter probabilities. Four previously announced departures are carried forward, not reverified. Only seven remaining situations freshly reassessed. Other rows carried forward. December 1/15 nulls remain unestimated; original February 1 baselines remain in source records. Current February 1 forecasts updated only for seven reviewed schools.

## Findings

### Michigan
Sam Webb Nov19 reports football urgency accelerated the AD timetable. Much of his case for a change is analysis, not a sourced decision. Alberts hire is confirmed; Whittingham publicly wants to return. Raise 35 to 50; no verified football search.
https://247sports.com/college/michigan/longformarticle/3r-report-trev-alberts-michigan-kyle-whittingham-future-copy-slug-292990539/
https://www.on3.com/teams/michigan-wolverines/news/kyle-whittingham-wants-to-stay-at-michigan-and-calls-the-self-sabotage-narrative-ridiculous/
https://12thman.com/news/2026/11/19/athletics-leadership-update-from-texas-aandm-president-dr-susan-ballabina

### Boston College
Hold 45. The hot-board opening is fan opinion; its lone staff reply rejects a fake reporter account, not confirms a search. No fresh decision reporting recovered. Syracuse and Miami remain pivotal.
https://247sports.com/college/boston-college/board/59454/contents/football-head-coach-hot-board-290166726/?page=1

### Wisconsin
Raise 35 to 40. Chancellor selection clears part of the previously reported governance uncertainty, but Bashir starts February 2027 and interim leadership continues. McNamara Nov15 expected a change after Minnesota; this is his assessment, not confirmation. Nov18 announcement buzz concerned the chancellor. Nov19 adds no decision.
https://247sports.com/college/wisconsin/board/23/contents/hot-board-20--289889901/?page=1
https://news.wisc.edu/rashid-bashir-named-chancellor-of-uwmadison/

### TCU
Lower 30 to 25. Jeremy Clark Nov15-16 reports continuing major-donor support and no completed firing arrangement; some trustees want change. He reports installment structure, not a reduced total buyout. Staff-plus-roster transition costs are distinct from HC buyout. National pressure coverage remains a contrary signal.
https://247sports.com/college/tcu/board/101445/contents/fire-sonny-new-hc-board-290448911/?page=1

### USC
Lower 30 to 25. Fresh national framing is cooler; private-contract expense and absence of verified decision evidence temper pressure. Final games remain important.
https://247sports.com/college/usc/board/102339/contents/cbs-sports-on-lincoln-riley-292992989/?page=1

### Clemson
Hold 15. Austin Hannon Nov17 and Cory Fravel Nov18 document a combative press conference; Swinney intentions do not constitute institutional backing. No new sourced dismissal decision or active-search evidence recovered.
https://247sports.com/college/clemson/board/22/contents/making-sense-of-what-dabo-swinney-said-in-outoftouch-duke-press-conference-292887019/?page=1

### Colorado
Hold 10. Jack Carlough Nov17 reports 2027 player-retention conversations. This is operational continuity, not a guarantee; no fresh sourced institutional move recovered.
https://247sports.com/college/colorado/board/104133/contents/takeaways-from-coach-primes-precincinnati-press-conference-292896649/?page=1

## National reporting and independence
CBS Nov19: Riley discussion cooled after Ohio State; Dykes remains under pressure. https://www.cbssports.com/college-football/news/2026-college-football-coaching-carousel-every-candidate-who-could-land-a-head-coaching-job-sorted-by-tier/
USC board repost of CBS is the same evidence chain, not corroboration. National hot-seat lists and candidate lists are opinion/context unless reporting identifies actual outreach. No active football search verified in this pass. The Athletic and ESPN subscriber articles were not freshly authenticated or reviewed in this pass.

## Source quality and scope
Michigan: Sam Webb original sourced VIP reporting (B/C) mixed with clearly labeled analysis; Anthony Broome Nov16 direct coach statements (A for statement only); Texas A&M official Nov19 departure acknowledgment (A).
Wisconsin: Jon McNamara and Nick Osen VIP staff comments (C for sourcing, D for assessment); UW Nov18 chancellor announcement (A). Chancellor announcement does not establish firing approval.
TCU: Jeremy Clark original staff comments (C); donor support, cost estimates and trustee dissatisfaction remain anonymously sourced and not independent corroboration. Jamie Plunkett references within the same reporting operation are not counted as a separate chain.
BC: AJ Black Sept27 staff rejection of a fake reporter claim; thread OP Sept19 is fan opinion (E). This particular board is older and adds no fresh firing report.
Clemson: Austin Hannon Nov17 article and Cory Fravel Nov18 staff commentary (B for press-conference reporting, D for interpretation).
Colorado: Jack Carlough Nov17 press-conference account (B), no institutional guarantee.
USC: Nov19 CBS article and its board repost are one chain (B reporting/D interpretation).

## Preservation and validation
The 79 program ranks, tiers and weights are unchanged. All 25 dashboard situations remain. Latest communicated Nov15 follow-up (WI35,TCU30) supplies comparison baseline; stale Nov15 ZIP had WI8,TCU35. Both archived. TCU buyout working estimate changes25M to20M based on Clark Nov16; total transition cost is not substituted for head-coach buyout.
VIP source text is summarized, not bulk republished. This is targeted review of selected threads and articles, not an exhaustive archive crawl. Lack of a newly recovered report is not evidence of job safety.
Website assets updated locally; no live deployment verified.