# November 21 targeted review

Pregame snapshot for the November 21 games. Odds are editorial estimates of a publicly open job or acknowledged search by each checkpoint. Neither program has a comparable November 6 baseline.

## Cincinnati · Scott Satterfield

December 7: 55%. February 1: 65%. Confidence: Moderate.

Cincinnati is 5–5 after a 4–0 start and has gone 1–5 since. In Year 4, a second consecutive late-season slide, fresh On3 reporting on pressure and a roughly $5.5M post-season buyout make a change more likely than retention. Colorado is the best remaining chance to clinch bowl eligibility before the BYU road finale. A strong finish would improve his case. No search announcement was identified in the reporting reviewed.

70% of reported 2027 and 2028 pay ($3.9M + $4.0M) after the 2026 contract year. A December dismissal may include remaining 2026 pay. The exact separation date and any amendments could change the amount.

- [National insider reporting (headline/date publicly visible)](https://www.on3.com/news/coaching-carousel-intel-pressure-building-at-wisconsin-cincinnati-more/)
- [Local analysis summarizing On3](https://sports.yahoo.com/articles/scott-satterfield-faces-latest-home-172851774.html)
- [Official schedule and results](https://gobearcats.com/sports/football/schedule/season/2026)
- [Local contract estimate based on reported terms](https://700wlw.iheart.com/featured/lance-mcalister/content/2026-01-04-bearcats-and-buyouts-satterfield-and-miller/)

## California · Tosh Lupoi

December 7: 12%. February 1: 18%. Confidence: Low to moderate.

Cal enters the Big Game 3–7 (2–5 ACC), with four straight losses and a 90–7 second-half scoring deficit over that stretch. Losing to Stanford again would add pressure after last year’s rivalry loss preceded Justin Wilcox’s dismissal. Lupoi is in Year 1 of Ron Rivera’s hire, and Cal would owe about $14.8M while still paying Wilcox through 2027. Coach retention is the more likely outcome. Stanford and Pitt are the immediate checkpoints.

The San Francisco Chronicle reports a $14.8M post-season estimate, reflecting 80% of remaining pay on the five-year deal. The separate Wilcox obligation is excluded.

- [Local rivalry preview and results](https://www.sfchronicle.com/sports/college/article/2026-big-game-matters-faltering-cal-football-22539851.php)
- [Local financial reporting and contract analysis](https://www.sfchronicle.com/sports/college/article/cal-big-hopes-big-donations-bears-stagger-big-22536578.php)
- [Independent local reporting and discussion](https://sfstandard.com/section-415/2026/11/13/cal-football-tosh-lupoi-ron-rivera-podcast/)
- [Reporting on released contract](https://www.sfchronicle.com/sports/college/article/cal-finalizes-head-coach-tosh-lupoi-s-deal-22491867.php)
