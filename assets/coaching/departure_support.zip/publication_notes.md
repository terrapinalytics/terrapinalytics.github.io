# November 15 follow-up

Wisconsin Dec7 35%, Feb1 42%; TCU Dec7 30%, Feb1 35%. The later staff-profile review supplied these judgments. February 1 values are editorial timing estimates. Dec1 and Dec15 are omitted because this saved dashboard does not include them. November 10 baselines remain available for comparison.
