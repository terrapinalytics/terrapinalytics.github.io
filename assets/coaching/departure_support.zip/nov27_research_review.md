# November 27 coaching carousel review

November 8 is the latest complete standalone baseline preserved for the November 13 reference date. Use the saved values without interpolation. A blank means the school had no saved baseline.

Estimates cover a public opening or acknowledged search, including voluntary departures. Current school-specific reviews follow. Other forecasts were carried forward after checking the national tracker for announced changes.

## Maryland
December 7 moved from 100% to 100%. February 1 moved from 100% to 100%.
Maryland’s opening remains unfilled. Charles Huff publicly ruled himself out. CBS reported interviews or interest involving other candidates, including Denard Wilson.
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-tracker-grades-2026/

## NC State
December 7 moved from 100% to 100%. February 1 moved from 100% to 100%.
NC State filled Dave Doeren’s former job with Philip Rivers. The odds reflect the opening that already occurred.
https://gopack.com/news/2026/11/13/rivers-named-head-coach-for-nc-state-football
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-tracker-grades-2026/

## Baylor
December 7 moved from 100% to 100%. February 1 moved from 100% to 100%.
Baylor’s job remains open. Jeff Traylor features prominently in search reporting. A hire is still pending.
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-tracker-grades-2026/

## USC
December 7 moved from 30% to 15%. February 1 moved from 40% to 25%.
Baylor and TCU offered plausible routes out for Riley. More recent search reporting centers Baylor on Jeff Traylor, and Jesse Simonton reports little belief in a TCU pursuit of Riley. Both jobs remain open.
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/
https://jesseresimonton.substack.com/p/the-walk-through-week-13-a-rivalry
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-tracker-grades-2026/

## Florida State
December 7 moved from 100% to 100%. February 1 moved from 100% to 100%.
Florida State announced Glenn Schumann as its head coach on November 23, filling the opening created by Mike Norvell’s departure.
https://seminoles.com/news/2026/11/23/football-glenn-schumann-named-florida-state-head-coach
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-tracker-grades-2026/

## TCU
December 7 moved from 100% to 100%. February 1 moved from 100% to 100%.
TCU’s search continues after Sonny Dykes’ dismissal. The school had yet to name a permanent replacement in the November 27 tracker.
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-tracker-grades-2026/
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/

## Boston College
December 7 moved from 35% to 35%. February 1 moved from 45% to 45%.
The Eagles enter the Miami finale 5–6 after beating Syracuse. Bowl eligibility is still within reach. The school’s game-week update adds no decision on O’Brien, so the estimate holds.
https://bceagles.com/news/2026/11/24/football-week-13-media-bc-at-4-miami

## South Carolina
December 7 moved from 6% to 10%. February 1 moved from 10% to 15%.
Consecutive 34–6 losses put pressure back on Beamer entering Clemson. The recent discussion about a potential buyout supports a modest increase. The account reviewed describes speculation about his future.
https://jesseresimonton.substack.com/p/the-walk-through-week-13-a-rivalry

## Colorado
December 7 moved from 10% to 40%. February 1 moved from 17% to 50%.
Colorado entered the UCF finale 4–7. Sanders has reached one bowl in four seasons, and CBS reports industry sources are watching the job. Jesse Simonton sees a split as plausible. Athletic director Fernando Lovo would have to weigh a dismissal costing about $25.5 million. A negotiated exit would require Sanders to agree. His public comments leave his plans open, and the reporting reviewed identifies neither an agreement nor an active search.
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/
https://jesseresimonton.substack.com/p/the-walk-through-week-13-a-rivalry
https://abcnews.com/Sports/wireStory/deion-sanders-colorado-finish-bumpy-season-hosting-ucf-138486031
https://www.denvergazette.com/2026/11/24/deion-sanders-im-winning-life-heading-into-cu-buffs-season-finale/

## Syracuse
December 7 moved from 7% to 7%. February 1 moved from 12% to 12%.
Syracuse enters the Notre Dame finale 5–6. The late-season record sustains some pressure, with no reported move in the reviewed coverage.
https://www.onefootdown.com/notre-dame-fighting-irish-football/87635/notre-dame-football-syracuse-orange-qa-with-troy-nunes-is-an-absolute-magician

## Michigan
December 7 moved from 50% to 60%. February 1 moved from 65% to 70%.
Michigan reversed course on hiring athletic director Trev Alberts. That leaves uncertainty about who would make a coaching change. Jesse Simonton reports that many around the sport still expect Whittingham to leave after one year. The Ohio State game is ahead and Michigan has announced no decision.
https://jesseresimonton.substack.com/p/the-walk-through-week-13-a-rivalry
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/

## Clemson
December 7 moved from 10% to 10%. February 1 moved from 18% to 18%.
The Duke win eased immediate pressure on Swinney heading into the South Carolina game. Earlier reporting that Clemson favored retaining him still carries more weight than reactions to individual results.
https://jesseresimonton.substack.com/p/the-walk-through-week-13-a-rivalry

## Wisconsin
December 7 moved from 40% to 20%. February 1 moved from 50% to 30%.
Wisconsin beat Purdue and led Minnesota 28–5 after three quarters. Eight wins and a rivalry trophy would strengthen Fickell’s case with the new athletic director. The forecast uses the in-game score, with the final and any retention announcement still pending at the evidence cutoff.
https://www.espn.com/college-football/scoreboard/_/date/20261127
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/
https://jesseresimonton.substack.com/p/the-walk-through-week-13-a-rivalry

## Mississippi State
December 7 moved from 8% to 20%. February 1 moved from 13% to 28%.
The Bulldogs finished with a 41–17 Egg Bowl loss. Jeff Lebby told reporters afterward that he had not discussed his future with administrators. Quarterback Kamario Taylor’s earlier decision to return provides some evidence of roster continuity.
https://sports.yahoo.com/college-football/articles/jeff-lebby-said-future-mississippi-220919777.html
https://www.espn.com/college-football/scoreboard/_/date/20261127
https://sports.yahoo.com/articles/does-kamario-taylor-message-mean-005745933.html

## Nebraska
December 7 moved from 6% to 8%. February 1 moved from 11% to 13%.
Iowa beat Nebraska 31–7 in the finale. That raises the near-term estimate slightly. The reported search for an offensive coordinator gives Rhule a route to addressing the season through staff changes.
https://www.espn.com/college-football/scoreboard/_/date/20261127
https://staging-aws.sports.yahoo.com/articles/more-staff-moves-expect-nebraska-171831129.html

## Cincinnati
December 7 moved from 45% to 35%. February 1 moved from 55% to 45%.
Bowl eligibility and the win over Texas Tech strengthen Satterfield’s case going into BYU. CBS still reports industry interest in the decision and puts his buyout below $6 million.
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/
https://jesseresimonton.substack.com/p/the-walk-through-week-13-a-rivalry

## California
December 7 moved from 18% to 38%. February 1 moved from 25% to 48%.
Cal takes a five-game losing streak into the Pitt game at 3–8. General manager Ron Rivera publicly discussed Lupoi’s struggles, and national reporting now treats a first-year change as plausible. The financial cost of another coaching change weighs in favor of a second season.
https://jesseresimonton.substack.com/p/the-walk-through-week-13-a-rivalry
https://www.cbssports.com/college-football/news/college-football-coaching-carousel-open-jobs-hot-seats-candidates/
