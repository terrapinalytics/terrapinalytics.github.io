# November 15, 2026 coaching odds review

Forecast target is a publicly open job or publicly acknowledged search by December 7. Changes are analyst judgments. The November 10 baseline is included. February 1 estimates were reviewed for changed rows and kept at least as high as December 7.

| School | Dec 7 before → after | Basis |
|---|---|---|
| Boston College | 40 → 45 | 41–7 loss at Notre Dame, now 4–6. Syracuse is the next test. The board's do-or-die discussion was fan interpretation. AJ Black's postgame thread supplied game analysis. |
| Michigan | 25 → 35 | 31–7 at Oregon, now 5–5. CBS discusses a possible mutual split and booster pressure. Detroit Free Press independently observed postgame fan heckling. The Victors Club thread showed frustration and competing donor theories. Direct evidence of an authorized search remains absent from the reviewed material. |
| TCU | 45 → 35 | 20–10 win over Kansas State after the trustees' meeting. Jeremy Clark reported that his sources said Dykes was not specifically discussed in the meeting and that prominent donors were divided. That is sourced VIP reporting, short of institutional confirmation. |
| USC | 25 → 30 | 27–13 loss at Indiana leaves USC 7–3. National coverage and Peristyle discussion show renewed pressure. High and disputed dismissal cost limits the increase. |
| Clemson | 8 → 15 | 20–6 home loss to Georgia Tech. CBS singled out Swinney. Judgment reflects escalating pressure and a large buyout. |
| Wisconsin | 3 → 8 | 24–21 loss to Maryland's interim staff. CBS's source-based pregame read leaned toward retention after bowl eligibility. One setback warrants a modest increase. |
| Mississippi State | 4 → 8 | 41–9 loss to Auburn. Results-based adjustment pending direct reporting on leadership. |
| South Carolina | 3 → 6 | 34–6 loss at Arkansas after four straight wins. CBS highlighted the setback. |
| Colorado | 15 → 10 | 42–32 win over ranked Houston. |
| Nebraska | 10 → 6 | 31–0 win at Rutgers. |
| Kansas | 8 → 5 | 37–14 win at West Virginia. |
| Syracuse | 10 → 7 | 34–31 win over NC State. |
| Washington | 7 → 5 | 21–14 win at Michigan State. |
| Arkansas | 6 → 3 | 34–6 win over South Carolina. |

The existing 25-row dashboard remains the comparison set. Outside it, Cal's 36–7 loss at Virginia and Pitt's 16–10 loss to interim-led FSU warrant follow-up. Virginia and Georgia Tech won. This pass did not verify fresh institutional evidence for those five leads, which remain outside the dashboard. USC's chart continues to display the prior $57M estimate. CBS cites a competing roughly $70M estimate and the contract remains private.

- Weekend scoreboard: https://www.on3.com/college/football/scoreboard/?date=2026-11-12&filter=fbs&phase=week-11&year=2026
- National analysis: https://www.cbssports.com/college-football/news/college-football-hot-seat-coaching-carousel-week-11/
- Michigan local reporting: https://sports.yahoo.com/articles/home-michigan-fans-yelled-kyle-033803154.html
- TCU trustees, Jeremy Clark and Jamie Plunkett: https://247sports.com/college/tcu/board/101445/contents/bot-meeting-292597333/?page=1
- BC postgame, AJ Black: https://247sports.com/college/boston-college/board/59454/contents/five-takeaways-from-boston-colleges-417-loss-to-notre-dame-292765195/?page=1
- Michigan postgame, Sam Webb: https://247sports.com/college/michigan/board/102410/contents/3-things-i-think-and-3-things-i-know-about-michigan-after-oregon-loss-whittinghams-biggest-miscalculation-292783616/?page=1
- USC postgame, RJ Abeytia: https://247sports.com/college/usc/board/102339/contents/instant-analysis-from-uscs-2713-loss-to-indiana-292753457/?page=1
