# Program rankings supporting data

Published Phase 4 source tables, as of October 26, 2026. Rankings are editorial judgments with stated category weights. Inputs are supporting observations, and do not provide an exact numerical decomposition of rank. Missing values remain missing. Source families retain their units and definitions. The download contains normalized tables and source references. Original raw reports remain in the research master.
