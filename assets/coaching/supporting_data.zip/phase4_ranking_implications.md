# Phase 4 ranking implications

All 79 desirability ranks and weights remain unchanged. These comparisons identify assumptions to review, not replacement rankings.

| Program | Existing rank | EADA football expenses FY22–24, $M 2025 USD | NCAA football expenses FY22–24, $M nominal | SP+ mean rank 2016–25 |
|---|---:|---:|---:|---:|
| Baylor | 41 | 42.95 | Not disclosed | 50.4 |
| Maryland | 43 | 35.93 | 33.94 | 65.0 |
| NC State | 44 | 34.25 | 33.50 | 47.7 |
| Wake Forest | 77 | 32.92 | Not disclosed | 59.9 |

Maryland and NC State have very similar NCAA football expense means ($33.94M and $33.50M). NC State's athletics ticket sales ($23.71M versus $13.47M) and operating contributions ($20.66M versus $10.34M) are substantially larger in FY2022–2024, while Maryland's conference economics should be assessed separately. These department-wide revenue lines are not football-only demand measures. NC State's better ten-year SP+ results reinforce a competitive-performance difference despite similar football spending.

Baylor's higher EADA spending supports a stronger resource position than a missing detailed NCAA report might suggest. Private nondisclosure cannot lower its resource score to zero. Wake Forest's EADA spending is much closer to Maryland and NC State than their large existing rank gap alone implies; review whether size, recruiting, conference economics and historical performance justify that gap. EADA definitions and its private-school usefulness do not make it interchangeable with NCAA accounts.

Official school reports support NC State 2022 attendance of 395,683 over seven home dates and Wake Forest 2023 attendance of 182,990 over six, improving provenance over conflicting secondary summaries. These figures are reported attendance, not independently counted spectators. Historic capacity and sell-through evidence remain too sparse for a robust all-program utilization comparison.

UNLV, James Madison, Boise State and Arizona State are among programs whose home-attendance comparisons are affected by source or postseason-scope repairs. Six new Mountain West/Pac-region salary observations improve current resource comparisons, but incomplete buyouts, bonuses and assistant pools prevent a complete contract ranking.

New FY2005–2009 financial observations improve longer-run institutional trends. Small FY2022–2024 differences should not be overinterpreted when definitions, one-time transactions or source completeness differ. The scholarship-definition conflicts and 14 revenue-total conflicts warrant targeted review before using those components in model weights.

NIL ranges remain incompatible source estimates. The Athletic-secondary and CBS football estimates for NC State, Maryland, Baylor and Wake Forest must remain separate, especially where NC State reporting disputes higher ranges. No averaging of roster budgets, institutional sharing and third-party NIL is justified.

The largest remaining sensitivity is unobserved detailed private-school financial/contract information, historical capacity, complete assistant compensation and actual football revenue-sharing payments. Any later model revision should review these confidence flags and use source-compatible peer comparisons rather than reward disclosure completeness.
